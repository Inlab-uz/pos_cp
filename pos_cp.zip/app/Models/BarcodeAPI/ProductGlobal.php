<?php

namespace App\Models\BarcodeAPI;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductGlobal extends Model
{
    use HasFactory;

    protected $table = 'products_global';
}
