<?php

return [
    'password' => 'Parollar kamida olti belgidan iborat bo\'lishi va tasdiq bilan mos kelishi kerak.',
    'reset'    => 'Parolingiz qayta tiklandi!',
    'sent'     => 'Parolni tiklash havolasini elektron pochta orqali yubordik!',
    'token'    => 'Ushbu parolni tiklash belgisi noto\'g\'ri.',
    'user'     => 'Ushbu elektron manzilga ega foydalanuvchini topa olmayapmiz.',
    'updated'  => 'Parolingiz o\'zgartirildi!',
];
