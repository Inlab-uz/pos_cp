<?php

return [
    'site_title' => 'Pos SYSTEM',
];
