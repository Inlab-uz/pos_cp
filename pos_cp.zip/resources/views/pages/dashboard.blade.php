@extends('layouts.admin')

@section('content')
    <!-- Make Cake -->
@endsection
