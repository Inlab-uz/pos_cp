<?php

return [
    'failed'   => 'Bunday ma\'lumotlarga ega foydalanuvchi topilmadi.',
    'throttle' => 'Kirish uchun juda ko\'p urinishlar mavjud: soniyalarda qayta urinib ko\'ring',
];
