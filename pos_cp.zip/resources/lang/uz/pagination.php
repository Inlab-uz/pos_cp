<?php

return [
    'previous' => '&laquo; Orqaga',
    'next'     => 'Oldinga &raquo;',
    'total_items' => 'Umumiy elementlar soni',
];
